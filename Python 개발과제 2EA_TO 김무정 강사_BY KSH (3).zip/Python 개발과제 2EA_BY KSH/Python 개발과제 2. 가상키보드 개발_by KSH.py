import tkinter as tk
from tkinter import messagebox
import requests
from bs4 import BeautifulSoup

# 날씨를 검색하는 함수
def get_weather():
    city = city_entry.get()
    if not city:
        messagebox.showwarning("입력 오류", "도시 이름을 입력하세요!")
        return
    
    url = f'https://www.google.com/search?q={city}+weather'
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}
    
    try:
        response = requests.get(url, headers=headers)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 날씨 정보를 파싱
        temp = soup.find('span', {'class': 'wob_t'}).text
        condition = soup.find('div', {'class': 'wob_d'}).text
        humidity = soup.find('span', {'id': 'wob_hm'}).text
        wind = soup.find('span', {'id': 'wob_ws'}).text
        
        # 결과를 출력
        result = f"도시: {city}\n온도: {temp}°C\n상태: {condition}\n습도: {humidity}\n풍속: {wind}"
        messagebox.showinfo("날씨 정보", result)
    
    except Exception as e:
        messagebox.showerror("오류", f"날씨 정보를 가져오는 데 실패했습니다: {e}")

# GUI 설정
root = tk.Tk()
root.title("구글 날씨 검색기")

# 도시 입력
city_label = tk.Label(root, text="도시 이름:")
city_label.pack(pady=10)

city_entry = tk.Entry(root, width=30)
city_entry.pack(pady=10)

# 검색 버튼
search_button = tk.Button(root, text="날씨 검색", command=get_weather)
search_button.pack(pady=20)

# 윈도우 크기 설정
root.geometry("300x200")

# GUI 실행
root.mainloop()