import sys
import requests
from bs4 import BeautifulSoup
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLineEdit, QPushButton, QLabel, QMessageBox


# 구글 날씨를 검색하는 함수
def googleweather(city):
    url = f'https://www.google.com/search?q={city}+weather'
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}
    
    try:
        # HTTP 요청
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # 오류 발생 시 예외 처리
        
        # HTML 파싱
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 날씨 정보 추출
        temp = soup.find('span', {'class': 'wob_t'}).text
        condition = soup.find('div', {'class': 'wob_d'}).text
        humidity = soup.find('span', {'id': 'wob_hm'}).text
        wind = soup.find('span', {'id': 'wob_ws'}).text
        
        # 결과 포맷
        result = f"도시: {city}\n온도: {temp}°C\n상태: {condition}\n습도: {humidity}\n풍속: {wind}"
        return result
    
    except Exception as e:
        return f"오류: 날씨 정보를 가져오는 데 실패했습니다. ({str(e)})"


# PyQt5 윈도우 클래스 정의
class WeatherApp(QWidget):
    def __init__(self):
        super().__init__()

        # 윈도우 초기화
        self.setWindowTitle('구글 날씨 검색기')
        self.setGeometry(100, 100, 400, 200)

        # 레이아웃 설정
        self.layout = QVBoxLayout()
        
        # 도시 입력 필드
        self.city_label = QLabel('도시 이름:')
        self.city_input = QLineEdit(self)
        self.city_input.setPlaceholderText('예: 서울')

        # 날씨 검색 버튼
        self.search_button = QPushButton('날씨 검색', self)
        self.search_button.clicked.connect(self.on_search)

        # 결과 레이블
        self.result_label = QLabel('날씨 정보를 입력 후 검색 버튼을 클릭하세요.', self)

        # 레이아웃에 위젯 추가
        self.layout.addWidget(self.city_label)
        self.layout.addWidget(self.city_input)
        self.layout.addWidget(self.search_button)
        self.layout.addWidget(self.result_label)
        
        # 레이아웃을 윈도우에 설정
        self.setLayout(self.layout)

    def on_search(self):
        city = self.city_input.text()
        if not city:
            QMessageBox.warning(self, "입력 오류", "도시 이름을 입력하세요!")
            return
        
        # 구글 날씨 정보 가져오기
        weather_info = googleweather(city)
        
        # 결과를 레이블에 출력
        self.result_label.setText(weather_info)


# 메인 실행 함수
if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = WeatherApp()
    window.show()
    sys.exit(app.exec_())